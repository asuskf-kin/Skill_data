# retail-math-eda — instalación

Skill de Claude Code para análisis exploratorio de datos de retail, combinando
métodos estadísticos con métricas comerciales de categoría.

## Instalar

Extrae la carpeta `retail-math-eda/` dentro de uno de estos directorios:

- **Solo para un proyecto:** `<tu-proyecto>/.claude/skills/`
- **Para todos tus proyectos:** `~/.claude/skills/` — en Windows, `C:\Users\<tu-usuario>\.claude\skills\`

El resultado debe quedar así:

```
.claude/skills/retail-math-eda/
  SKILL.md
  references/
  scripts/
```

Reinicia Claude Code. La skill se activa sola cuando la conversación trata de
ventas de retail, transacciones, canasta de compra, SKU, elasticidad-precio,
inventario o comportamiento de compra. También se puede invocar por nombre.

## Dependencias del módulo de cálculo

`scripts/retail_eda.py` necesita **polars, numpy y scipy**. scikit-learn es
opcional: habilita el estimador de información mutua KSG. No requiere pandas.

```bash
pip install polars numpy scipy scikit-learn
```

Verifica con el self-test incluido:

```bash
python scripts/retail_eda.py --self-test
```

Debe terminar en `RESULTADO: todo ok`. Las pruebas no son solo de humo: varias
comprueban que los estimadores recuperan parámetros sembrados — por ejemplo, que
la regresión de elasticidad devuelve el coeficiente real que se usó para generar
los datos sintéticos.

## Qué incluye

| Archivo | Contenido |
|---|---|
| `SKILL.md` | El flujo de trabajo en seis pasos y los cinco errores clásicos |
| `references/statistical-methods.md` | Fórmulas, estimadores, pruebas y umbrales de interpretación |
| `references/retail-metrics.md` | Definiciones de métricas comerciales y unit economics |
| `references/gotchas.md` | Las cinco trampas explicadas: por qué ocurren y cómo detectarlas |
| `scripts/retail_eda.py` | Implementación en polars/numpy/scipy de los pasos computacionales |

## Alcance

Cubre: integridad y faltantes, distribuciones de cola pesada, dependencias con
control de FDR, market basket, RFM y cohortes, elasticidad-precio, ABC-XYZ y
descomposición temporal. Exige datos transaccionales para los pasos 4B a 5; con
un corte transversal solo son viables los pasos 1 a 3.
